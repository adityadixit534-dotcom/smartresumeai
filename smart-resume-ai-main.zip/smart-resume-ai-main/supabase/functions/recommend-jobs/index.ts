import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { resumeText } = await req.json();

    if (!resumeText) {
      return new Response(
        JSON.stringify({ error: "Resume text is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are an expert career advisor. Analyze the resume and:
1. Extract the top skills found in the resume.
2. Recommend 5-10 suitable job roles based on skills, experience, and education.
3. For each job role, provide search URLs for these platforms: LinkedIn, Naukri, Internshala, Unstop, Indeed.

Use URL patterns:
- LinkedIn: https://www.linkedin.com/jobs/search/?keywords={encoded role}
- Naukri: https://www.naukri.com/{role-hyphenated}-jobs
- Internshala: https://internshala.com/internships/{role-hyphenated}-internship
- Unstop: https://unstop.com/jobs?search={encoded role}
- Indeed: https://www.indeed.com/jobs?q={encoded role}

Use the recommend_jobs tool to return your response.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `RESUME:\n${resumeText.slice(0, 4000)}` },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "recommend_jobs",
              description: "Return extracted skills and job recommendations with multi-platform links",
              parameters: {
                type: "object",
                properties: {
                  detected_skills: {
                    type: "array",
                    items: { type: "string" },
                    description: "Skills extracted from the resume",
                  },
                  jobs: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string", description: "Job role title" },
                        reason: { type: "string", description: "Why this role fits (1 sentence)" },
                        platforms: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              name: { type: "string", description: "Platform name" },
                              url: { type: "string", description: "Direct job search URL" },
                            },
                            required: ["name", "url"],
                            additionalProperties: false,
                          },
                        },
                      },
                      required: ["title", "reason", "platforms"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["detected_skills", "jobs"],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "recommend_jobs" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please try again later." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const text = await response.text();
      console.error("AI gateway error:", response.status, text);
      throw new Error("Job recommendation failed");
    }

    const aiData = await response.json();
    const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) throw new Error("No result from AI");

    const result = JSON.parse(toolCall.function.arguments);
    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("recommend-jobs error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
