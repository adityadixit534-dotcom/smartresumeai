import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Sparkles, ArrowLeft, Upload, Loader2, Target, Brain,
  TrendingUp, MessageSquare, FileText, BarChart3, Briefcase,
  ExternalLink, RefreshCw, Code2,
} from "lucide-react";
import { motion } from "framer-motion";
import JobMatchSection from "@/components/analyzer/JobMatchSection";

interface AnalysisResult {
  ats_score: number;
  missing_skills: string[];
  improvements: string[];
  interview_questions: string[];
}

interface JobPlatform {
  name: string;
  url: string;
}

interface JobRecommendation {
  title: string;
  reason: string;
  platforms: JobPlatform[];
}

interface PastAnalysis {
  id: string;
  created_at: string;
  ats_score: number;
  job_title: string;
}

const ResumeAnalyzer = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [resumeText, setResumeText] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [pastAnalyses, setPastAnalyses] = useState<PastAnalysis[]>([]);
  const [monthlyUsage, setMonthlyUsage] = useState(0);
  const [fileName, setFileName] = useState("");
  const [jobRecs, setJobRecs] = useState<JobRecommendation[]>([]);
  const [detectedSkills, setDetectedSkills] = useState<string[]>([]);
  const [loadingJobs, setLoadingJobs] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (user) {
      loadPastAnalyses();
      loadUsageCount();
    }
  }, [user]);

  const loadPastAnalyses = async () => {
    const { data } = await supabase
      .from("analyses")
      .select("id, created_at, ats_score, job_title")
      .eq("user_id", user!.id)
      .order("created_at", { ascending: false })
      .limit(10);
    if (data) setPastAnalyses(data as PastAnalysis[]);
  };

  const loadUsageCount = async () => {
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);
    const { count } = await supabase
      .from("analyses")
      .select("*", { count: "exact", head: true })
      .eq("user_id", user!.id)
      .gte("created_at", startOfMonth.toISOString());
    setMonthlyUsage(count ?? 0);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "File too large", description: "Max 5MB allowed", variant: "destructive" });
      return;
    }
    setFileName(file.name);
    const text = await file.text();
    setResumeText(text);
    toast({ title: "File loaded", description: `${file.name} content extracted.` });
  };

  const handleAnalyze = async () => {
    if (!resumeText.trim() || !jobDescription.trim()) {
      toast({ title: "Missing info", description: "Please provide both resume and job description.", variant: "destructive" });
      return;
    }

    setAnalyzing(true);
    setJobRecs([]);
    try {
      const { data, error } = await supabase.functions.invoke("analyze-resume", {
        body: { resumeText, jobDescription },
      });
      if (error) throw error;
      setResult(data as AnalysisResult);

      await supabase.from("analyses").insert({
        user_id: user!.id,
        ats_score: data.ats_score,
        missing_skills: data.missing_skills,
        improvements: data.improvements,
        interview_questions: data.interview_questions,
        job_title: jobDescription.slice(0, 100),
        resume_text: resumeText.slice(0, 5000),
      });
      setMonthlyUsage((prev) => prev + 1);
      loadPastAnalyses();

      // Auto-fetch job recommendations
      fetchJobRecs();
    } catch (err: any) {
      toast({ title: "Analysis failed", description: err.message || "Something went wrong", variant: "destructive" });
    } finally {
      setAnalyzing(false);
    }
  };

  const fetchJobRecs = async () => {
    setLoadingJobs(true);
    try {
      const { data, error } = await supabase.functions.invoke("recommend-jobs", {
        body: { resumeText },
      });
      if (error) throw error;
      setDetectedSkills(data.detected_skills || []);
      setJobRecs(data.jobs || []);
    } catch (err: any) {
      toast({ title: "Job recommendations failed", description: err.message, variant: "destructive" });
    } finally {
      setLoadingJobs(false);
    }
  };

  const downloadReport = () => {
    if (!result) return;
    const content = `SmartResume AI Analysis Report
================================

ATS Score: ${result.ats_score}/100

Missing Skills:
${result.missing_skills.map((s) => `• ${s}`).join("\n")}

Resume Improvements:
${result.improvements.map((s) => `• ${s}`).join("\n")}

Interview Questions:
${result.interview_questions.map((q, i) => `${i + 1}. ${q}`).join("\n")}
${jobRecs.length > 0 ? `\nRecommended Jobs:\n${jobRecs.map((j, i) => `${i + 1}. ${j.title} — ${j.reason}`).join("\n")}` : ""}
`;
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "smartresume-analysis.txt";
    a.click();
    URL.revokeObjectURL(url);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-lg sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <span className="font-display font-bold text-lg">Resume Analyzer</span>
          </div>
        </div>
      </header>

      <div className="container py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {/* Upload */}
            <div className="bg-card rounded-xl shadow-card border border-border/50 p-6">
              <Label className="font-display font-semibold mb-3 block">Upload Resume</Label>
              <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-border rounded-xl cursor-pointer hover:border-primary/50 transition-colors">
                <Upload className="w-8 h-8 text-muted-foreground mb-2" />
                <span className="text-sm text-muted-foreground">
                  {fileName || "Click to upload PDF or DOCX (max 5MB)"}
                </span>
                <input type="file" className="hidden" accept=".pdf,.docx,.txt" onChange={handleFileUpload} />
              </label>
              <div className="mt-4">
                <Label className="text-sm text-muted-foreground mb-1 block">Or paste resume text</Label>
                <Textarea value={resumeText} onChange={(e) => setResumeText(e.target.value)} placeholder="Paste your resume content here..." className="min-h-[120px]" />
              </div>
            </div>

            {/* Job description */}
            <div className="bg-card rounded-xl shadow-card border border-border/50 p-6">
              <Label className="font-display font-semibold mb-3 block">Job Description</Label>
              <Textarea value={jobDescription} onChange={(e) => setJobDescription(e.target.value)} placeholder="Paste the job description you're applying for..." className="min-h-[120px]" />
            </div>

            <Button variant="hero" className="w-full h-14 text-lg" disabled={analyzing} onClick={handleAnalyze}>
              {analyzing ? <><Loader2 className="w-5 h-5 animate-spin mr-2" /> Analyzing...</> : <><Sparkles className="w-5 h-5 mr-2" /> Analyze Resume</>}
            </Button>

            {/* Results */}
            {result && (
              <motion.div className="space-y-6" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                {/* ATS Score */}
                <div className="bg-card rounded-xl shadow-card border border-border/50 p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <Target className="w-5 h-5 text-primary" />
                    <h3 className="font-display font-semibold text-lg">ATS Score</h3>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className={`text-5xl font-display font-bold ${result.ats_score >= 70 ? "text-primary" : result.ats_score >= 40 ? "text-accent" : "text-destructive"}`}>
                      {result.ats_score}
                    </div>
                    <div className="flex-1">
                      <div className="w-full h-3 bg-secondary rounded-full overflow-hidden">
                        <motion.div
                          className={`h-full rounded-full ${result.ats_score >= 70 ? "gradient-primary" : result.ats_score >= 40 ? "gradient-accent" : "bg-destructive"}`}
                          initial={{ width: 0 }} animate={{ width: `${result.ats_score}%` }} transition={{ duration: 1, ease: "easeOut" }}
                        />
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {result.ats_score >= 70 ? "Great match!" : result.ats_score >= 40 ? "Needs improvement" : "Major improvements needed"}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Missing Skills */}
                <div className="bg-card rounded-xl shadow-card border border-border/50 p-6">
                  <div className="flex items-center gap-3 mb-4"><Brain className="w-5 h-5 text-primary" /><h3 className="font-display font-semibold text-lg">Missing Skills</h3></div>
                  <div className="flex flex-wrap gap-2">
                    {result.missing_skills.map((skill) => (
                      <span key={skill} className="px-3 py-1.5 rounded-lg bg-destructive/10 text-destructive text-sm font-medium">{skill}</span>
                    ))}
                  </div>
                </div>

                {/* Improvements */}
                <div className="bg-card rounded-xl shadow-card border border-border/50 p-6">
                  <div className="flex items-center gap-3 mb-4"><TrendingUp className="w-5 h-5 text-primary" /><h3 className="font-display font-semibold text-lg">Improvement Suggestions</h3></div>
                  <ul className="space-y-3">
                    {result.improvements.map((imp, i) => (
                      <li key={i} className="flex gap-3 text-sm">
                        <span className="w-6 h-6 rounded-full gradient-primary text-primary-foreground flex items-center justify-center flex-shrink-0 text-xs font-bold">{i + 1}</span>
                        <span>{imp}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Interview Questions */}
                <div className="bg-card rounded-xl shadow-card border border-border/50 p-6">
                  <div className="flex items-center gap-3 mb-4"><MessageSquare className="w-5 h-5 text-primary" /><h3 className="font-display font-semibold text-lg">Interview Questions</h3></div>
                  <ol className="space-y-3">
                    {result.interview_questions.map((q, i) => (
                      <li key={i} className="flex gap-3 text-sm">
                        <span className="font-display font-bold text-primary">{i + 1}.</span>
                        <span>{q}</span>
                      </li>
                    ))}
                  </ol>
                </div>

                {/* AI Job Match Section */}
                <JobMatchSection
                  detectedSkills={detectedSkills}
                  jobRecs={jobRecs}
                  loadingJobs={loadingJobs}
                  onRefresh={fetchJobRecs}
                />

                <Button variant="secondary" onClick={downloadReport} className="w-full">
                  <FileText className="w-4 h-4 mr-2" /> Download Report
                </Button>
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="bg-card rounded-xl shadow-card border border-border/50 p-6">
              <div className="flex items-center gap-3 mb-4"><BarChart3 className="w-5 h-5 text-primary" /><h3 className="font-display font-semibold">Usage</h3></div>
              <p className="text-3xl font-display font-bold">{monthlyUsage}</p>
              <p className="text-sm text-muted-foreground">analyses this month</p>
            </div>
            <div className="bg-card rounded-xl shadow-card border border-border/50 p-6">
              <h3 className="font-display font-semibold mb-4">Recent Reports</h3>
              {pastAnalyses.length === 0 ? (
                <p className="text-sm text-muted-foreground">No analyses yet.</p>
              ) : (
                <ul className="space-y-3">
                  {pastAnalyses.map((a) => (
                    <li key={a.id} className="flex items-center justify-between text-sm">
                      <span className="truncate max-w-[150px]">{a.job_title || "Untitled"}</span>
                      <span className={`font-display font-bold ${a.ats_score >= 70 ? "text-primary" : a.ats_score >= 40 ? "text-accent" : "text-destructive"}`}>{a.ats_score}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResumeAnalyzer;
