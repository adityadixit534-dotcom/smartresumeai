import Navbar from "@/components/landing/Navbar";
import HeroSection from "@/components/landing/HeroSection";
import FeaturesSection from "@/components/landing/FeaturesSection";
import FooterSection from "@/components/landing/FooterSection";

const Index = () => (
  <main>
    <Navbar />
    <HeroSection />
    <FeaturesSection />
    <FooterSection />
  </main>
);

export default Index;
