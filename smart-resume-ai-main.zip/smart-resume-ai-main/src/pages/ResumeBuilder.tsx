import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, FileText, Loader2, Sparkles, Download } from "lucide-react";
import { motion } from "framer-motion";

interface ResumeData {
  summary: string;
  skills_section: string[];
  experience_section: { title: string; bullets: string[] }[];
  education_section: string;
  projects_section?: { name: string; description: string }[];
  certifications_section?: string[];
}

const ResumeBuilder = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [name, setName] = useState("");
  const [education, setEducation] = useState("");
  const [skills, setSkills] = useState("");
  const [experience, setExperience] = useState("");
  const [projects, setProjects] = useState("");
  const [certifications, setCertifications] = useState("");
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<ResumeData | null>(null);

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  const handleGenerate = async () => {
    if (!name.trim() || !skills.trim()) {
      toast({ title: "Missing info", description: "Name and skills are required.", variant: "destructive" });
      return;
    }

    setGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke("build-resume", {
        body: { name, education, skills, experience, projects, certifications },
      });
      if (error) throw error;
      setResult(data as ResumeData);
      toast({ title: "Resume generated!", description: "Scroll down to preview and download." });
    } catch (err: any) {
      toast({ title: "Generation failed", description: err.message || "Something went wrong", variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  };

  const downloadPDF = () => {
    if (!result) return;

    const lines: string[] = [];
    lines.push(name.toUpperCase());
    lines.push("=".repeat(name.length));
    lines.push("");
    lines.push("PROFESSIONAL SUMMARY");
    lines.push("-".repeat(20));
    lines.push(result.summary);
    lines.push("");
    lines.push("SKILLS");
    lines.push("-".repeat(6));
    lines.push(result.skills_section.join(" • "));
    lines.push("");
    lines.push("EXPERIENCE");
    lines.push("-".repeat(10));
    result.experience_section.forEach((exp) => {
      lines.push(exp.title);
      exp.bullets.forEach((b) => lines.push(`  • ${b}`));
      lines.push("");
    });
    lines.push("EDUCATION");
    lines.push("-".repeat(9));
    lines.push(result.education_section);
    lines.push("");
    if (result.projects_section?.length) {
      lines.push("PROJECTS");
      lines.push("-".repeat(8));
      result.projects_section.forEach((p) => {
        lines.push(`${p.name}: ${p.description}`);
      });
      lines.push("");
    }
    if (result.certifications_section?.length) {
      lines.push("CERTIFICATIONS");
      lines.push("-".repeat(14));
      result.certifications_section.forEach((c) => lines.push(`• ${c}`));
    }

    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${name.replace(/\s+/g, "_")}_ATS_Resume.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-lg sticky top-0 z-50">
        <div className="container flex items-center h-16 gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <FileText className="w-5 h-5 text-primary" />
          <span className="font-display font-bold text-lg">ATS Resume Maker</span>
        </div>
      </header>

      <div className="container py-8 max-w-3xl">
        <div className="space-y-5">
          <div className="bg-card rounded-xl shadow-card border border-border/50 p-6 space-y-4">
            <div>
              <Label className="font-display font-semibold">Full Name *</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="John Doe" className="mt-1" />
            </div>
            <div>
              <Label className="font-display font-semibold">Education</Label>
              <Textarea value={education} onChange={(e) => setEducation(e.target.value)} placeholder="B.Tech Computer Science, XYZ University, 2024" className="mt-1" />
            </div>
            <div>
              <Label className="font-display font-semibold">Skills *</Label>
              <Textarea value={skills} onChange={(e) => setSkills(e.target.value)} placeholder="Python, Machine Learning, SQL, Data Analysis, Power BI..." className="mt-1" />
            </div>
            <div>
              <Label className="font-display font-semibold">Experience</Label>
              <Textarea value={experience} onChange={(e) => setExperience(e.target.value)} placeholder="Software Intern at ABC Corp — Built REST APIs..." className="mt-1 min-h-[100px]" />
            </div>
            <div>
              <Label className="font-display font-semibold">Projects</Label>
              <Textarea value={projects} onChange={(e) => setProjects(e.target.value)} placeholder="E-commerce platform using React and Node.js..." className="mt-1" />
            </div>
            <div>
              <Label className="font-display font-semibold">Certifications</Label>
              <Textarea value={certifications} onChange={(e) => setCertifications(e.target.value)} placeholder="AWS Cloud Practitioner, Google Data Analytics..." className="mt-1" />
            </div>
          </div>

          <Button variant="hero" className="w-full h-14 text-lg" disabled={generating} onClick={handleGenerate}>
            {generating ? <><Loader2 className="w-5 h-5 animate-spin mr-2" /> Generating...</> : <><Sparkles className="w-5 h-5 mr-2" /> Generate ATS Resume</>}
          </Button>

          {result && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-xl shadow-card border border-border/50 p-8 space-y-6">
              <h2 className="font-display font-bold text-2xl text-center">{name}</h2>

              <div>
                <h3 className="font-display font-semibold text-sm text-muted-foreground uppercase tracking-wider mb-2">Professional Summary</h3>
                <p className="text-sm leading-relaxed">{result.summary}</p>
              </div>

              <div>
                <h3 className="font-display font-semibold text-sm text-muted-foreground uppercase tracking-wider mb-2">Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {result.skills_section.map((s, i) => (
                    <span key={i} className="px-3 py-1 rounded-lg bg-primary/10 text-primary text-sm font-medium">{s}</span>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-display font-semibold text-sm text-muted-foreground uppercase tracking-wider mb-2">Experience</h3>
                {result.experience_section.map((exp, i) => (
                  <div key={i} className="mb-3">
                    <p className="font-semibold text-sm">{exp.title}</p>
                    <ul className="list-disc list-inside text-sm text-muted-foreground mt-1 space-y-1">
                      {exp.bullets.map((b, j) => <li key={j}>{b}</li>)}
                    </ul>
                  </div>
                ))}
              </div>

              <div>
                <h3 className="font-display font-semibold text-sm text-muted-foreground uppercase tracking-wider mb-2">Education</h3>
                <p className="text-sm">{result.education_section}</p>
              </div>

              {result.projects_section && result.projects_section.length > 0 && (
                <div>
                  <h3 className="font-display font-semibold text-sm text-muted-foreground uppercase tracking-wider mb-2">Projects</h3>
                  {result.projects_section.map((p, i) => (
                    <div key={i} className="mb-2">
                      <p className="font-semibold text-sm">{p.name}</p>
                      <p className="text-sm text-muted-foreground">{p.description}</p>
                    </div>
                  ))}
                </div>
              )}

              {result.certifications_section && result.certifications_section.length > 0 && (
                <div>
                  <h3 className="font-display font-semibold text-sm text-muted-foreground uppercase tracking-wider mb-2">Certifications</h3>
                  <ul className="list-disc list-inside text-sm space-y-1">
                    {result.certifications_section.map((c, i) => <li key={i}>{c}</li>)}
                  </ul>
                </div>
              )}

              <Button variant="hero" className="w-full" onClick={downloadPDF}>
                <Download className="w-4 h-4 mr-2" /> Download Resume
              </Button>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResumeBuilder;
