import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Briefcase, Loader2, Sparkles, Upload, ExternalLink, RefreshCw } from "lucide-react";
import { motion } from "framer-motion";

interface Platform {
  name: string;
  url: string;
}

interface JobRecommendation {
  title: string;
  reason: string;
  platforms: Platform[];
}

const platformColors: Record<string, string> = {
  LinkedIn: "bg-[hsl(210,80%,45%)]",
  Naukri: "bg-[hsl(200,70%,40%)]",
  Internshala: "bg-[hsl(220,60%,50%)]",
  Unstop: "bg-[hsl(25,90%,55%)]",
  Indeed: "bg-[hsl(210,50%,35%)]",
};

const JobFinder = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [resumeText, setResumeText] = useState("");
  const [fileName, setFileName] = useState("");
  const [loading, setLoading] = useState(false);
  const [jobs, setJobs] = useState<JobRecommendation[]>([]);
  const [skills, setSkills] = useState<string[]>([]);

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "File too large", description: "Max 5MB allowed", variant: "destructive" });
      return;
    }
    setFileName(file.name);
    const text = await file.text();
    setResumeText(text);
  };

  const handleFind = async () => {
    if (!resumeText.trim()) {
      toast({ title: "Missing resume", description: "Please provide your resume.", variant: "destructive" });
      return;
    }

    setLoading(true);
    setJobs([]);
    setSkills([]);
    try {
      const { data, error } = await supabase.functions.invoke("recommend-jobs", {
        body: { resumeText },
      });
      if (error) throw error;
      setSkills(data.detected_skills || []);
      setJobs(data.jobs || []);
    } catch (err: any) {
      toast({ title: "Failed", description: err.message || "Something went wrong", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-lg sticky top-0 z-50">
        <div className="container flex items-center h-16 gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <Briefcase className="w-5 h-5 text-primary" />
          <span className="font-display font-bold text-lg">AI Multi-Platform Job Finder</span>
        </div>
      </header>

      <div className="container py-8 max-w-4xl">
        <div className="space-y-6">
          {/* Upload Section */}
          <div className="bg-card rounded-xl shadow-card border border-border/50 p-6">
            <Label className="font-display font-semibold mb-3 block">Upload Resume</Label>
            <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-border rounded-xl cursor-pointer hover:border-primary/50 transition-colors">
              <Upload className="w-8 h-8 text-muted-foreground mb-2" />
              <span className="text-sm text-muted-foreground">{fileName || "Click to upload (.txt, .pdf, .docx — max 5MB)"}</span>
              <input type="file" className="hidden" accept=".pdf,.docx,.txt" onChange={handleFileUpload} />
            </label>
            <div className="mt-4">
              <Label className="text-sm text-muted-foreground mb-1 block">Or paste resume text</Label>
              <Textarea value={resumeText} onChange={(e) => setResumeText(e.target.value)} placeholder="Paste your resume content here..." className="min-h-[150px]" />
            </div>
          </div>

          <Button variant="hero" className="w-full h-14 text-lg" disabled={loading} onClick={handleFind}>
            {loading ? <><Loader2 className="w-5 h-5 animate-spin mr-2" /> Analyzing resume &amp; finding jobs...</> : <><Sparkles className="w-5 h-5 mr-2" /> Find Matching Jobs</>}
          </Button>

          {/* Detected Skills */}
          {skills.length > 0 && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-xl shadow-card border border-border/50 p-6">
              <h2 className="font-display font-bold text-xl mb-4">🎯 Detected Skills</h2>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill, i) => (
                  <Badge key={i} variant="secondary" className="text-sm px-3 py-1">
                    {skill}
                  </Badge>
                ))}
              </div>
            </motion.div>
          )}

          {/* Job Results */}
          {jobs.length > 0 && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="font-display font-bold text-xl">💼 Recommended Jobs ({jobs.length})</h2>
                <Button variant="outline" size="sm" onClick={handleFind} disabled={loading}>
                  <RefreshCw className={`w-4 h-4 mr-1 ${loading ? "animate-spin" : ""}`} />
                  Find More Jobs
                </Button>
              </div>

              {jobs.map((job, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-card rounded-xl shadow-card border border-border/50 p-5"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0">
                      <span className="text-primary-foreground font-bold text-sm">{i + 1}</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-display font-semibold text-lg">{job.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{job.reason}</p>

                      {/* Platform Cards */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 mt-4">
                        {job.platforms.map((platform, j) => (
                          <a
                            key={j}
                            href={platform.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 rounded-lg border border-border/50 px-3 py-2 hover:bg-accent/50 transition-colors group"
                          >
                            <div className={`w-2 h-2 rounded-full flex-shrink-0 ${platformColors[platform.name] || "bg-primary"}`} />
                            <span className="text-xs font-medium truncate">{platform.name}</span>
                            <ExternalLink className="w-3 h-3 text-muted-foreground ml-auto opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
                          </a>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default JobFinder;
