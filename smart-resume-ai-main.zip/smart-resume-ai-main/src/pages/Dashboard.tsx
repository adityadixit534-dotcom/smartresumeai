import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import {
  Sparkles, LogOut, FileText, Briefcase, Target, Loader2,
} from "lucide-react";
import { motion } from "framer-motion";

const toolCards = [
  {
    title: "Resume Analyzer",
    description: "Upload your resume and a job description to get an ATS score, missing skills, improvements, and interview questions.",
    icon: Target,
    path: "/dashboard/analyzer",
    gradient: "gradient-primary",
  },
  {
    title: "ATS Resume Maker",
    description: "Enter your details and let AI generate a professional, ATS-optimized resume you can download as PDF.",
    icon: FileText,
    path: "/dashboard/resume-builder",
    gradient: "gradient-accent",
  },
  {
    title: "AI Job Finder",
    description: "Get personalized job recommendations across LinkedIn, Naukri, Internshala, Unstop & Indeed based on your resume skills.",
    icon: Briefcase,
    path: "/dashboard/job-finder",
    gradient: "gradient-primary",
  },
];

const Dashboard = () => {
  const { user, loading: authLoading, signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-lg sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-display font-bold text-lg">SmartResume AI</span>
          </div>
          <Button variant="ghost" size="sm" onClick={() => { signOut(); navigate("/"); }}>
            <LogOut className="w-4 h-4 mr-1" /> Logout
          </Button>
        </div>
      </header>

      <div className="container py-12">
        <div className="mb-10">
          <h1 className="font-display font-bold text-3xl mb-2">Your AI Tools</h1>
          <p className="text-muted-foreground">Choose a tool to get started.</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {toolCards.map((tool, i) => (
            <motion.div
              key={tool.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-card rounded-xl shadow-card border border-border/50 p-6 flex flex-col cursor-pointer hover:shadow-elevated transition-shadow"
              onClick={() => navigate(tool.path)}
            >
              <div className={`w-12 h-12 rounded-xl ${tool.gradient} flex items-center justify-center mb-4`}>
                <tool.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <h2 className="font-display font-semibold text-xl mb-2">{tool.title}</h2>
              <p className="text-muted-foreground text-sm flex-1">{tool.description}</p>
              <Button variant="hero" className="mt-6 w-full">
                Open Tool
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
