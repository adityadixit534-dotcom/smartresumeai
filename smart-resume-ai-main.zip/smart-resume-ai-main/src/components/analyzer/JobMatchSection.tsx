import { Briefcase, ExternalLink, Loader2, RefreshCw, Code2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

interface JobPlatform {
  name: string;
  url: string;
}

interface JobRecommendation {
  title: string;
  reason: string;
  platforms: JobPlatform[];
}

interface JobMatchSectionProps {
  detectedSkills: string[];
  jobRecs: JobRecommendation[];
  loadingJobs: boolean;
  onRefresh: () => void;
}

const platformColors: Record<string, string> = {
  LinkedIn: "bg-primary/10 text-primary hover:bg-primary/20",
  Naukri: "bg-accent/10 text-accent hover:bg-accent/20",
  Internshala: "bg-chart-3/10 text-chart-3 hover:bg-chart-3/20",
  Unstop: "bg-chart-4/10 text-chart-4 hover:bg-chart-4/20",
  Indeed: "bg-chart-5/10 text-chart-5 hover:bg-chart-5/20",
};

const JobMatchSection = ({ detectedSkills, jobRecs, loadingJobs, onRefresh }: JobMatchSectionProps) => {
  return (
    <div className="space-y-6">
      {/* Detected Skills */}
      {detectedSkills.length > 0 && (
        <motion.div
          className="bg-card rounded-xl shadow-card border border-border/50 p-6"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex items-center gap-3 mb-4">
            <Code2 className="w-5 h-5 text-primary" />
            <h3 className="font-display font-semibold text-lg">Detected Skills</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {detectedSkills.map((skill) => (
              <span
                key={skill}
                className="px-3 py-1.5 rounded-lg bg-primary/10 text-primary text-sm font-medium"
              >
                {skill}
              </span>
            ))}
          </div>
        </motion.div>
      )}

      {/* Recommended Jobs */}
      <motion.div
        className="bg-card rounded-xl shadow-card border border-border/50 p-6"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Briefcase className="w-5 h-5 text-primary" />
            <h3 className="font-display font-semibold text-lg">Recommended Jobs for You</h3>
          </div>
          {jobRecs.length > 0 && (
            <Button variant="ghost" size="sm" onClick={onRefresh} disabled={loadingJobs}>
              <RefreshCw className={`w-4 h-4 mr-1 ${loadingJobs ? "animate-spin" : ""}`} />
              Find More Jobs
            </Button>
          )}
        </div>

        {loadingJobs ? (
          <div className="flex flex-col items-center justify-center py-8 gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Analyzing your profile and finding matching jobs...</p>
          </div>
        ) : jobRecs.length > 0 ? (
          <div className="grid gap-4">
            {jobRecs.map((job, i) => (
              <motion.div
                key={i}
                className="border border-border/50 rounded-xl p-5 hover:border-primary/30 transition-colors bg-background/50"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 * i }}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <h4 className="font-display font-semibold text-base">{job.title}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{job.reason}</p>
                  </div>
                </div>

                {/* Platform Links */}
                <div className="flex flex-wrap gap-2 mt-4">
                  {job.platforms.map((platform) => (
                    <a
                      key={platform.name}
                      href={platform.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                        platformColors[platform.name] || "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                      }`}
                    >
                      <ExternalLink className="w-3 h-3" />
                      {platform.name}
                    </a>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">Job recommendations will appear after analysis.</p>
        )}
      </motion.div>
    </div>
  );
};

export default JobMatchSection;
