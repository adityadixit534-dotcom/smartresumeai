import { Sparkles } from "lucide-react";

const FooterSection = () => (
  <footer className="py-12 border-t border-border/50 bg-card">
    <div className="container">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg gradient-primary flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-primary-foreground" />
          </div>
          <span className="font-display font-bold">SmartResume AI</span>
        </div>
        <p className="text-sm text-muted-foreground">
          © 2026 SmartResume AI. All rights reserved.
        </p>
      </div>
    </div>
  </footer>
);

export default FooterSection;
