import { motion } from "framer-motion";
import { Target, Brain, MessageSquare, TrendingUp, FileText, BarChart3 } from "lucide-react";

const features = [
  {
    icon: Target,
    title: "ATS Score Analysis",
    description: "Get a precise 0-100 score showing how well your resume passes Applicant Tracking Systems.",
  },
  {
    icon: Brain,
    title: "Missing Skills Detection",
    description: "AI identifies crucial skills missing from your resume based on the job description.",
  },
  {
    icon: TrendingUp,
    title: "Resume Improvement",
    description: "Get AI-rewritten bullet points with stronger, more professional wording.",
  },
  {
    icon: MessageSquare,
    title: "Interview Questions",
    description: "Receive top 5 likely interview questions tailored to the specific job description.",
  },
  {
    icon: FileText,
    title: "PDF & DOCX Support",
    description: "Upload resumes in PDF or DOCX format. We extract and analyze the content instantly.",
  },
  {
    icon: BarChart3,
    title: "Analysis History",
    description: "Access all your past analysis reports anytime from your dashboard.",
  },
];

const FeaturesSection = () => (
  <section className="py-24 bg-background" id="features">
    <div className="container">
      <div className="text-center mb-16">
        <motion.h2
          className="text-3xl md:text-5xl font-bold font-display mb-4"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Everything You Need to{" "}
          <span className="text-gradient-primary">Land the Job</span>
        </motion.h2>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Our AI analyzes your resume against ATS systems and provides actionable insights to improve your chances.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, i) => (
          <motion.div
            key={feature.title}
            className="p-6 rounded-xl bg-card shadow-card border border-border/50 hover:shadow-elevated transition-all duration-300 group"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="w-12 h-12 rounded-lg gradient-primary flex items-center justify-center mb-4 group-hover:animate-pulse-glow transition-all">
              <feature.icon className="w-6 h-6 text-primary-foreground" />
            </div>
            <h3 className="font-display font-semibold text-lg mb-2">{feature.title}</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default FeaturesSection;
